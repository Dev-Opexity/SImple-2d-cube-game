var canvas = document.getElementById("mainCanvas");
var context = canvas.getContext("2d");

var canvas = document.getElementById("mainCanvas");
var context = canvas.getContext("2d");

var keys = [];

var width = 500, height = 400, cspeed = 3, speed = 3;

var p1t = "player1";
var p2t = "player2";
var score = 9; 
var scorec = 9; 
var life = 3;
var lifec = 3;
var gw = "";
var bw = "";
var dt = "Warning this is still in development!";

var earn = "none";

var player = {
x: 0,
y: 499,
width: 40,
height: 40
};

var cube = {
x: 0,
y: 80,
width: 40,
height: 40
};

window.addEventListener("keydown", function(e){
    keys[e.keyCode] = true;
}, false);

window.addEventListener("keyup", function(e){
    delete keys[e.keyCode];
}, false);

/*
up - 38
down - 40
left - 37
right - 39
up - 87
down - 83
left - 35
right - 68
*/
function game(){
update();
render();
}

function update(){
if(collision(player, cube)) process();
if(keys[38]) player.y-=speed;
if(keys[40]) player.y+=speed;
if(keys[37]) player.x-=speed;
if(keys[39]) player.x+=speed;

if(player.x < 0) player.x = 0;
if(player.y < 0) player.y = 0;
if(player.x >= width - player.width) player.x = width - player.width;
if(player.y >= height - player.height) player.y = height - player.height;

if(collision(player, cube)) process1();
if(keys[87]) cube.y-=cspeed;
if(keys[83]) cube.y+=cspeed;
if(keys[65]) cube.x-=cspeed;
if(keys[68]) cube.x+=cspeed;

if(cube.x < 0) cube.x = 0;
if(cube.y < 0) cube.y = 0;
if(cube.x >= width - cube.width) cube.x = width - cube.width;
if(cube.y >= height - cube.height) cube.y = height - cube.height;

if(score > 9) powerup1(); 
if(score > 19) powerup2();
if(score > 29) powerup3();
if(score > 39) powerup4();
if(score > 49) powerup5();
if(scorec > 9) powerup1c(); 
if(scorec > 19) powerup2c();
if(scorec > 29) powerup3c();
if(scorec > 39) powerup4c();
if(scorec > 49) powerup5c();

if(life < 1) die();
if(lifec < 1) diec();

}

function render(){
context.clearRect(0, 0, width, height);

context.fillStyle = "blue";
context.fillRect(player.x, player.y, player.width, player.height);

context.fillStyle = "green";
context.fillRect(cube.x, cube.y, cube.width, cube.height);

context.fillStyle = "blue";
context.font = "italic 30px helvetica";
context.fillText(score, 10 ,30 );

context.fillStyle = "green";
context.font = "italic 30px helvetica";
context.fillText(scorec, 100 ,30 );

context.fillStyle = "red";
context.font = "italic 30px helvetica";
context.fillText(earn, 10 ,200 );
check();

context.fillStyle = "blue";
context.font = "italic 30px helvetica";
context.fillText(life, 200 ,30 );

context.fillStyle = "green";
context.font = "italic 30px helvetica";
context.fillText(lifec, 300 ,30 );

context.fillStyle = "blue";
context.font = "italic 30px helvetica";
context.fillText(bw, 10 ,50 );

context.fillStyle = "green";
context.font = "italic 30px helvetica";
context.fillText(gw, 10 ,50 );

context.fillStyle = "black";
context.font = "italic 10px helvetica";
context.fillText(p2t, cube.x + 5, cube.y + 15 );

context.fillStyle = "black";
context.font = "italic 10px helvetica";
context.fillText(p1t, player.x + 5, player.y + 15 );

context.fillStyle = "orange";
context.font = "italic 10px helvetica";
context.fillText(dt, 220 , 400);
}

function die(){
if (life < 1)  gw = "Green wins!";

}

function diec(){
if (lifec < 1)  bw = "Blue wins!";

}

function process(){
score+=10;
lifec-=1;
cube.x = Math.random() * (width - 20);
cube.y = Math.random() * (height - 20);
}

function process1(){
scorec+=10;
life-=1;
player.x = Math.random() * (width - 20);
player.y = Math.random() * (height - 20);
}

function collision(first, second, third){
return !(first.x > second.x + second.width ||
first.x+first.width<second.x ||
first.y > second.y + second.height||
first.y+first.height<second.y);

return !(second.x > first.x + first.width ||
second.x+second.width<first.x ||
second.y > first.y + first.height ||
second.y+second.height<first.y);
}

function powerup1(){
if (score > 9) speed = 5;
}

function powerup2(){
if (score > 19) speed = 7;
}
function powerup3(){
if (score > 29) speed = 9;
}

function powerup4(){
if (score > 39) speed = 11;
}

function powerup5(){
if (score > 49) speed = 13;
}

function powerup1c(){
if (scorec > 9) cspeed = 5;
}

function powerup2c(){
if (scorec > 19) cspeed = 7;
}

function powerup3c(){
if (scorec > 29) cspeed = 9;
}

function powerup4c(){
if (scorec > 39) cspeed = 11;
}

function powerup5c(){
if (scorec > 49) cspeed = 13;
}

function check(){
if (score > 9)  earn = "+2 speed";
if (score > 19)  earn = "+4 speed";
if (score > 29)  earn = "+6 speed";
if (score > 39)  earn = "+8 speed";
if (score > 49)  earn = "+10 speed";
if (scorec > 9)  earn = "+2 speed";
if (scorec > 19)  earn = "+4 speed";
if (scorec > 29)  earn = "+6 speed";
if (scorec > 39)  earn = "+8 speed";
if (scorec > 49)  earn = "+10 speed";
}

setInterval(function(){
game();
}, 1000/30);
